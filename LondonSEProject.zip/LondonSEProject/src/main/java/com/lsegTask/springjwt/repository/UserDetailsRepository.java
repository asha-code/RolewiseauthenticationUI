package com.lsegTask.springjwt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lsegTask.springjwt.models.Details;
import com.lsegTask.springjwt.models.Role;

@Repository
public interface UserDetailsRepository extends JpaRepository<Details, Long> {

}
