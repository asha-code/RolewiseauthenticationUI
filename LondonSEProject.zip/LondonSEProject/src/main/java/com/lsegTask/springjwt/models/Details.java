package com.lsegTask.springjwt.models;

import javax.annotation.processing.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Details {
	@Id
	@GeneratedValue
	@Column(name="UID")
private Integer UID;
	@Column(name="TransDateTime")
private String TransDateTime;
	@Column(name="TransactionStatus")
private String TransactionStatus;
	@Column(name="Position")
private String Position;
	
	@Column(name="FXRateHQ")
private Integer FXRateHQ;
	
	@Column(name="Currency")
private Integer Currency;
	
	@Column(name="Comment")
private String Comment;
	
	@Column(name="ClientName")
private String ClientName;
	
	@Column(name="BUserName")
private String BUserName;
	
	@Column(name="BOUserName")
private String BOUserName;
	
	@Column(name="Amount")
private Integer Amount;

public Details() {
	
}

public Integer getUID() {
	return UID;
}

public void setUID(Integer uID) {
	UID = uID;
}

public String getTransDateTime() {
	return TransDateTime;
}

public void setTransDateTime(String transDateTime) {
	TransDateTime = transDateTime;
}

public String getTransactionStatus() {
	return TransactionStatus;
}

public void setTransactionStatus(String transactionStatus) {
	TransactionStatus = transactionStatus;
}

public String getPosition() {
	return Position;
}

public void setPosition(String position) {
	Position = position;
}

public Integer getFXRateHQ() {
	return FXRateHQ;
}

public void setFXRateHQ(Integer fXRateHQ) {
	FXRateHQ = fXRateHQ;
}

public Integer getCurrency() {
	return Currency;
}

public void setCurrency(Integer currency) {
	Currency = currency;
}

public String getComment() {
	return Comment;
}

public void setComment(String comment) {
	Comment = comment;
}

public String getClientName() {
	return ClientName;
}

public void setClientName(String clientName) {
	ClientName = clientName;
}

public String getBUserName() {
	return BUserName;
}

public void setBUserName(String bUserName) {
	BUserName = bUserName;
}

public String getBOUserName() {
	return BOUserName;
}

public void setBOUserName(String bOUserName) {
	BOUserName = bOUserName;
}

public Integer getAmount() {
	return Amount;
}

public void setAmount(Integer amount) {
	Amount = amount;
}



}
