import React from 'react'
import HomeSection from '../../HomeSection'
import { homeObjThree } from '../../../Style'

function SignUp() {
  return (
    <>
      <HomeSection {...homeObjThree} />
    </>
  )
}

export default SignUp
