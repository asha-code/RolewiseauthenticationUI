import React from 'react'
import HomeSection from '../../HomeSection'
import Pricing from '../../Pricing'
import { homeObjTwo } from '../../../Style'

function Products() {
  return (
    <>
      <HomeSection {...homeObjTwo} />
      <Pricing />
    </>
  )
}

export default Products
