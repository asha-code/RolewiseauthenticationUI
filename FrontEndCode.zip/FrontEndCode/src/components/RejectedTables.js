import React, { Component } from "react";

import BootStrapTable from "react-bootstrap-table-next";  


import AuthService from "../services/auth.service";
export default class RejectedTables extends Component {
    constructor(){        
        super();
        this.state = {
            list: [{  
                name: 'Ayaan',  
                age: 26  
                },{  
                name: 'Ahana',  
                age: 22  
                },{  
                name: 'Peter',  
                age: 40   
                },{  
                name: 'Virat',  
                age: 30  
                },{  
                name: 'Rohit',  
                age: 32  
                },{  
                name: 'Dhoni',  
                age: 37  
                }]  
        }                
    }

    componentDidMount() {
        debugger
        this.getList();       
    }

    getList(){
        debugger
        const NewList = AuthService.fetchRejectedReuqests();
        console.log("NewList",NewList)

   }

   render(){ 
        const columnsTable =  [{  
            Header: 'Name',  
            accessor: 'name'  
           },{  
           Header: 'Age',  
           accessor: 'age'  
           }]  ;

        let tableStyle = {
            //backgroundColor: "#FCFD96",
            marginRight: "auto",
            marginLeft: "auto",
            marginBottom: "20px",
            fontSize: "14px",
            textAlign: "center",
        }

        return( 
            // <Main {...headerProps}>
                <div>                              
                    <BootStrapTable
                        data= {this.state.list}
                        columns={columnsTable}
                        showPaginationBottom= {true}
                        className= "-striped -highlight"
                        style={tableStyle}
                        noDataText = {"Please Wait"}                        
                        getTdProps={(state, rowInfo, column, instance) => {
                            return {
                              onClick: (e, handleOriginal) => {
                                console.log('A Td Element was clicked!')
                                console.log('it produced this event:', e)
                                console.log('It was in this column:', column)
                                console.log('It was in this row:', rowInfo)
                                console.log('It was in this table instance:', instance)
                              }
                            }
                          }}

                    />    
                </div>              
            // </Main>
        )        
    }
} 